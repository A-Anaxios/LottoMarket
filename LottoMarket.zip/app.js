      import React from 'react';
import { View, Text, Image } from 'react-native';

export default function App() {
  return (
    <View style={{ flex:1, justifyContent:'center', alignItems:'center' }}>
      <Image source={require('./assets/logo.png')} style={{ width:120, height:120, marginBottom:20 }} />
      <Text style={{ fontSize:20 }}>Welcome to LottoMarket!</Text>
    </View>
  );
}